import express from 'express'
import mongoose from 'mongoose'
import examcontroller from './controllers/examController.js'


const app = express()
const port = process.env.port || '3000'
const database_url = "mongodb://127.0.0.1:27017";
const dbcon = async(database_url)=>{
    try{
        const DB_OPTIONS = {
            dbname:"externaldb",
        };
        await mongoose.connect(database_url,DB_OPTIONS)
        console.log("connected successfully");
    }
    catch(err){
        console.log(err);
    }
}

app.set("view engine","ejs");

app.use(express.urlencoded({extended:true}));

app.get('/',examcontroller.signuppage)
app.post('/',examcontroller.signupuser)
app.get('/login',examcontroller.loginpage)
app.post('/login',examcontroller.loginuser)
app.get('/home',examcontroller.homepage)
app.post('/home',examcontroller.addproduct)
app.get('/viewproduct',examcontroller.viewproduct)
app.get('/editproduct/:id/',examcontroller.editproduct)
app.post('/editproduct/:id',examcontroller.updateproduct)
app.get('/deleteproduct/:id/',examcontroller.deleteproduct)
dbcon(database_url)

app.listen(port,()=>{
    console.log(`server listening at port: ${port}`);
})