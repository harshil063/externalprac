import productModel from "../models/product.js";
import studentModel from "../models/student.js";

class examcontroller{
    static signuppage = (req,res)=>{
        res.render("signup")
    }

    static signupuser = async(req,res)=>{
        try{
            const doc = new studentModel({
                name:req.body.name,
                email:req.body.email,
                password:req.body.password,
                cpassword:req.body.cpassword,
            })
            await doc.save()
            res.redirect('/login')
        }catch(error){
            console.log(error);
        }
    }

    static loginpage = (req,res)=>{
        res.render("login");
    }

    static loginuser = async(req,res)=>{
        try{
            const email = req.body.email;
            const password = req.body.password;
            const result = await studentModel.findOne({email:email})
            if(result.email == email && result.password == password){
                res.redirect("/home");
            }else{
                console.log("invalid username or password");
            }
        }catch(error){
            console.log(error);
        }
    }

    static viewproduct = async (req,res)=>{
        try{
            const result = await productModel.find()
            res.render("viewproduct",{data:result})
        }catch(error){
            console.log(error);
        }
    }
    static homepage = (req,res)=>{
        res.render("home")
    }
    static addproduct =async (req,res)=>{
        try{
            const doc = new productModel({
            pname : req.body.pname,
            pprice : req.body.pprice,
            pqty : req.body.pqty,
            })
            await doc.save();
            res.redirect('viewproduct')
            
        }catch(err){
            console.log(err);
        }
    }

    static editproduct = async(req,res)=>{
        try{
            const result = await productModel.findById(req.params.id)
            console.log(result);
            res.render("editproduct",{data:result})
        }catch(err){
            console.log(err);
        }
    }
    
    static updateproduct =async (req,res)=>{
        try{
            console.log(req.params.id);
            console.log(req.body);
            const result = await productModel.findByIdAndUpdate(req.params.id,req.body)
            res.redirect("/viewproduct")
        }catch(error){
            console.log(error);
        }
    }

    static deleteproduct = async(req,res)=>{
        try{
            console.log(req.params.id);
            const result = await productModel.findByIdAndDelete(req.params.id)
            res.redirect("/viewproduct")
        }catch(err){
            console.log(err);
        }
    }
}

export default examcontroller;