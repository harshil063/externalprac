import mongoose from "mongoose";
const productSchema = new mongoose.Schema({
    pname: {type:String, required:true},
    pprice: {type:Number,required:true},
    pqty: {type:Number,required:true},
})

const productModel = mongoose.model('Product',productSchema);


export default productModel